var uhack = require('./uhack.js');

var out = uhack('test');

console.log(out);